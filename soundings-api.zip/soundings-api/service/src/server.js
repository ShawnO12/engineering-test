import http from 'node:http';

import pg from 'pg';

const port = Number(process.env.PORT ?? 8080);

const pool = new pg.Pool({
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

async function soundingsNear(lat, lon, radiusMetres) {
  const sql =
    'SELECT id, depth_m, surveyed_on, ST_AsGeoJSON(geom) AS geometry FROM soundings ' +
    `WHERE ST_DWithin(geom::geography, ST_MakePoint(${lon}, ${lat})::geography, ${radiusMetres}) ` +
    'ORDER BY surveyed_on DESC LIMIT 500';
  const result = await pool.query(sql);
  return result.rows;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  try {
    if (url.pathname === '/') {
      return send(res, 200, { service: 'soundings-api' });
    }

    if (url.pathname === '/health') {
      await pool.query('SELECT 1');
      return send(res, 200, { status: 'ok' });
    }

    if (url.pathname === '/v1/soundings') {
      const lat = url.searchParams.get('lat');
      const lon = url.searchParams.get('lon');
      const radius = url.searchParams.get('radius') ?? '500';
      if (lat == null || lon == null) return send(res, 400, { error: 'lat and lon are required' });

      return send(res, 200, { soundings: await soundingsNear(lat, lon, radius) });
    }

    return send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error(err);
    return send(res, 500, { error: 'Internal error' });
  }
});

function send(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

server.listen(port, () => {
  console.log(`soundings-api listening on ${port}`);
});
