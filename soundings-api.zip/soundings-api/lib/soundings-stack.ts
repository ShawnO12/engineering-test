import { Duration, RemovalPolicy, Stack } from 'aws-cdk-lib';
import type { StackProps } from 'aws-cdk-lib';
import * as cloudwatchActions from 'aws-cdk-lib/aws-cloudwatch-actions';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecsPatterns from 'aws-cdk-lib/aws-ecs-patterns';
import * as elbv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as sns from 'aws-cdk-lib/aws-sns';
import type { Construct } from 'constructs';

export interface SoundingsStackProps extends StackProps {
  envName: string;
}

export class SoundingsStack extends Stack {
  constructor(scope: Construct, id: string, props: SoundingsStackProps) {
    super(scope, id, props);

    const config = this.node.tryGetContext('environments')[props.envName];

    const vpc = ec2.Vpc.fromLookup(this, 'Vpc', { vpcName: config.vpcName });

    // Survey teams upload new data here. The web viewer loads the survey
    // thumbnails straight from the bucket.
    const uploads = new s3.Bucket(this, 'SurveyUploads', {
      bucketName: 'soundings-survey-uploads',
      publicReadAccess: true,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ACLS,
      removalPolicy: RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
    });

    // Database
    const dbSecurityGroup = new ec2.SecurityGroup(this, 'DatabaseSecurityGroup', {
      vpc,
      description: 'Soundings database',
    });
    dbSecurityGroup.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(5432), 'Postgres');

    const database = new rds.DatabaseInstance(this, 'Database', {
      engine: rds.DatabaseInstanceEngine.postgres({ version: rds.PostgresEngineVersion.VER_16 }),
      instanceType: new ec2.InstanceType(config.dbInstanceClass),
      vpc,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      securityGroups: [dbSecurityGroup],
      databaseName: config.dbName,
      allocatedStorage: config.dbStorageGb,
      credentials: rds.Credentials.fromGeneratedSecret('soundings'),
      multiAz: props.envName === 'prod',
      backupRetention: Duration.days(props.envName === 'production' ? 7 : 1),
      deletionProtection: false,
      removalPolicy: RemovalPolicy.DESTROY,
    });

    // Key for the chart tile service. CloudFormation creates a placeholder,
    // then we put the real key in by hand after the first deploy.
    const tileKey = new secretsmanager.Secret(this, 'TileServiceKey', {
      description: 'Chart tile service API key',
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ endpoint: config.tileEndpoint }),
        generateStringKey: 'apiKey',
      },
    });

    // API
    const cluster = new ecs.Cluster(this, 'Cluster', { vpc });
    const repository = ecr.Repository.fromRepositoryName(this, 'Repository', 'soundings-api');

    const api = new ecsPatterns.ApplicationLoadBalancedFargateService(this, 'Api', {
      cluster,
      cpu: 512,
      memoryLimitMiB: 1024,
      desiredCount: config.desiredCount,
      circuitBreaker: { rollback: true },
      taskImageOptions: {
        image: ecs.ContainerImage.fromEcrRepository(repository, 'latest'),
        containerPort: 8080,
        environment: {
          DB_HOST: database.dbInstanceEndpointAddress,
          DB_NAME: config.dbName,
          DB_USER: 'soundings',
          UPLOAD_BUCKET: uploads.bucketName,
          TILE_ENDPOINT: config.tileEndpoint,
        },
        secrets: {
          DB_PASSWORD: ecs.Secret.fromSecretsManager(database.secret!, 'password'),
          TILE_API_KEY: ecs.Secret.fromSecretsManager(tileKey, 'apiKey'),
        },
      },
    });

    database.connections.allowDefaultPortFrom(api.service);

    uploads.grantReadWrite(api.taskDefinition.taskRole);
    // Needed for the upload endpoint
    api.taskDefinition.taskRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonS3FullAccess'));

    // Alerts go to the ops channel
    const alerts = sns.Topic.fromTopicArn(this, 'Alerts', 'arn:aws:sns:ap-southeast-2:333333333333:ops-alerts');
    const errors = api.loadBalancer.metrics
      .httpCodeElb(elbv2.HttpCodeElb.ELB_5XX_COUNT, { period: Duration.minutes(5) })
      .createAlarm(this, 'Api5xxAlarm', {
        threshold: 10,
        evaluationPeriods: 1,
        alarmDescription: 'Soundings API is returning errors',
      });
    errors.addAlarmAction(new cloudwatchActions.SnsAction(alerts));
  }
}
