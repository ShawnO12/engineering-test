# Technical exercise: Senior DevOps Engineer

Thanks for taking the time to do this exercise.

The Soundings API in this repository is a made-up service, but it uses the same tools we use every day: AWS CDK in TypeScript, ECS Fargate, RDS PostgreSQL, S3, Secrets Manager, GitHub Actions, and AppStream with PowerShell.

It has problems. Some are obvious and some are not. We want to see how you find them, how you rank them, and how you would fix them.

## Before you start

- The exercise should take about **2 hours**. Please don't spend more than 3. We would rather see good judgement on the important things than an answer for everything.
- You don't need an AWS account, and you shouldn't deploy anything. `npm install` and `npm test` work without AWS access.
- You don't need a Windows machine for the PowerShell part.
- You can use AI tools and online documentation. If you do, tell us which ones and what you used them for. In the interview we'll ask you to talk through your answers, so make sure you understand and agree with everything you send us.

## Part 1: Review (about 60 minutes)

Review the repository as if a colleague had asked you to approve it for production. This includes:

- everything on the `main` branch, including the AppStream install script
- the open change on the `change/prod-db-sizing` branch, which the team wants to merge next

Write your review in a file called `REVIEW.md`. For each issue, tell us:

1. what the problem is and where it is
2. why it matters (what could go wrong, and how likely it is)
3. what you would do about it

Put the most important issues first. If there is anything you would stop from going to production, say so.

## Part 2: Build (about 45 minutes)

Choose **one** of these tasks and make the change in the repository.

**A. Protect the data.** Change the database and the survey upload bucket so they are safe to run in production. Add tests that would fail if someone removed those protections later.

**B. Fix the pipeline.** Change the GitHub Actions workflow so it uses OIDC instead of access keys, and deploys to dev, then preprod, then prod, with an approval step before prod. You won't be able to run it. Tell us what you would need to set up in AWS and GitHub to make it work.

**C. Fix the AppStream install.** Rewrite `appstream/Install-SoundingsCli.ps1` so it is safe to run on the image builder and works for staff when they use the AppStream image. Tell us how you would test it.

Commit your change with a short explanation of what you did and why.

## Part 3: Design (about 15 minutes)

The next release of the API changes the database schema when it starts up.

In a file called `DESIGN.md`, write up to half a page on how you would release it to preprod and then prod. Tell us how you would check it worked, and how you would roll it back if it didn't.

## Sending it back

Zip up the whole folder, including the hidden `.git` folder so we can see your commits, but not `node_modules`. Email the zip back to us at least one working day before your interview.

In the interview we'll spend 20 to 30 minutes on your answers. We'll ask you to walk us through your most important findings and the choices you made.

If anything in this exercise isn't clear, or you need any adjustments to take part, please get in touch.
