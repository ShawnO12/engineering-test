<#
    Installs the Soundings CLI on the AppStream image builder.

    Run this as Administrator on the image builder, then create the image
    with Image Assistant. Staff launch the CLI from the AppStream catalogue.
#>

param(
    [string]$Version = "2.3.1"
)

Set-ExecutionPolicy Unrestricted -Force

$InstallerUrl  = "http://downloads.soundings-vendor.example/cli/$Version/soundings-cli-$Version.msi"
$InstallerPath = "$env:TEMP\soundings-cli.msi"
$InstallDir    = "C:\Program Files\Soundings CLI"

Write-Host "Downloading Soundings CLI $Version"
Invoke-WebRequest -Uri $InstallerUrl -OutFile $InstallerPath

Write-Host "Installing"
Start-Process msiexec.exe -ArgumentList "/i $InstallerPath /qn"

# Add the CLI to the path so staff can run it from any prompt
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";$InstallDir", "Machine")

# Connection settings so staff can query soundings without having to log in
$DbHost     = "soundings-prod.c1a2b3c4d5e6.ap-southeast-2.rds.amazonaws.com"
$DbUser     = "soundings"
$DbPassword = "Sound1ngs-Prod!"

$ConfigDir = "$env:USERPROFILE\.soundings"
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null

@"
[database]
host=$DbHost
port=5432
name=soundings
user=$DbUser
password=$DbPassword
"@ | Set-Content -Path "$ConfigDir\config.ini"

Write-Host "Configured connection for $DbUser (password $DbPassword)"
Write-Host "Done"
