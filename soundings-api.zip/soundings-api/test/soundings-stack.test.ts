import { readFileSync } from 'node:fs';
import { test } from 'node:test';

import { App } from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';

import { SoundingsStack } from '../lib/soundings-stack.ts';

const cdkJson = JSON.parse(readFileSync(new URL('../cdk.json', import.meta.url), 'utf-8'));

test('creates the soundings stack', () => {
  const app = new App({ context: cdkJson.context });
  const stack = new SoundingsStack(app, 'soundings-dev', {
    envName: 'dev',
    env: { account: '111111111111', region: 'ap-southeast-2' },
  });

  const template = Template.fromStack(stack);

  template.resourceCountIs('AWS::ECS::Service', 1);
  template.resourceCountIs('AWS::RDS::DBInstance', 1);
  template.resourceCountIs('AWS::S3::Bucket', 1);
});
