# Soundings API

## Background

A sounding is a measured water depth at a point. Survey teams collect millions of them, and hydrographers use them to build and check nautical charts.

The Soundings API lets staff look up the soundings near a location. It runs as a container on AWS ECS Fargate, reads from a PostgreSQL (PostGIS) database on RDS, and stores new survey uploads in S3.

Staff use the API from the Soundings CLI, which is installed on our AppStream image. They don't have direct access to AWS.

## Repository layout

| Folder | What's in it |
| --- | --- |
| `bin/`, `lib/` | AWS CDK app (TypeScript) that deploys the infrastructure |
| `test/` | Tests for the CDK app |
| `service/` | The API service and its Dockerfile |
| `appstream/` | Install script for the AppStream image builder |
| `.github/workflows/` | CI/CD |

## Environments

We have three environments, each in its own AWS account: `dev`, `preprod` and `prod`. Their settings are in `cdk.json`.

## Development

You need Node.js 24 or later.

Install dependencies

```
npm install
```

Check the types

```
npm run build
```

Run the tests

```
npm test
```

Synthesise the CloudFormation template for an environment

```
npx cdk synth -c env=dev
```

## Deployment

Pushing to GitHub runs the `Deploy` workflow. It runs the tests, builds and pushes the API image, and deploys to prod.

The workflow uses the access keys of the `ci-deployer` IAM user, which are stored as GitHub secrets. The user has `AdministratorAccess` so CDK can create whatever it needs.

To deploy an environment by hand:

```
npx cdk deploy -c env=preprod
```
